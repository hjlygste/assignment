document.addEventListener("DOMContentLoaded", function () {
    const submitButton = document.querySelector(".submit");
  
    submitButton.addEventListener("click", function () {
      // Get form input values
      const name = document.querySelector("#name").value;
      const birthdate = document.querySelector("#birthdate").value;
      const address = document.querySelector("#address").value;
  
      // Create a new jsPDF instance
      const {jsPDF} = window.jspdf;
      const doc = new jsPDF();
  
      // Add content to the PDF
      doc.text(20, 20, "Member Details");
      doc.text(20, 30, `Name: ${name}`);
      doc.text(20, 40, `Birthdate: ${birthdate}`);
      doc.text(20, 50, "Address:");
      doc.text(20, 60, address);
  
      // Save the PDF or open it in a new tab
      doc.save("member_details.pdf");
    });
  });
  