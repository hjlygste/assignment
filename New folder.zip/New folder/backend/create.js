const logOut = document.querySelector('.logout');
    logOut.onclick = () => {
        sessionStorage.clear();
        location.reload();
    }

    const submitBtn = document.querySelector('.submitBtn');
    const username = document.querySelector('.username');
const password = document.querySelector('.password');
submitBtn.addEventListener('click', () => {
    

    fetch('/add-admin', {
        method: 'post',
        headers: new Headers({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
            username: username.value,
            password: password.value
        })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.username) {
            // Handle an error, display a message, or take appropriate action
            console.log('Admin creation failed:', data.error); // Replace with your error handling code
        } else {
            // Admin creation was successful
            console.log('Admin created:', data.username);
            location.href = '/';
            
        }
    })
});
