const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'sqluser',
  password: 'abcd',
  database: 'users'
});

const app = express();

let initialPath = path.join(__dirname, 'backend');

app.use(bodyParser.json());
app.use(express.static(initialPath));

app.get('/', (req, res) => {
    res.sendFile(path.join(initialPath, 'create-admin.html'));
});

app.get('/create-admin', (req, res) => {
    res.sendFile(path.join(initialPath, 'create-admin.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(initialPath, 'login.html'));
});

app.post('/login-user', (req, res) => {
    const { username, password } = req.body;

    connection.query('SELECT username FROM test WHERE username = ? AND password = ?', [username, password], (error, results) => {
        if (error) {
            res.json('Error accessing the database.');
        } else if (results.length) {
            res.json(results[0]);
        } else {
            res.json('Username or password is incorrect');
        }
    });
});

app.post('/add-admin', (req, res) => {
    const { username, password } = req.body;

    // Insert the admin data into the database
    connection.query('INSERT INTO test (username, password) VALUES (?, ?)', [username, password], (error, results) => {
        if (error) {
            if (error.code === 'ER_DUP_ENTRY') {
                res.status(400).json('Username already exists'); // Return a status code 400 for bad request
            } else {
                res.status(500).json('An error occurred'); // Return a status code 500 for internal server error
            }
        } else {
            res.json({ username }); // Return success response
        }
    });
});



app.listen(3000, () => {
    console.log('Listening on port 3000...');
});
